import React from 'react'
import Link from "next/link";
import Catnav from "../component/Catnav";
import SidePanel from '../component/SidePanel';
import Sidebar from './Sidebar';
const CatApi = () => {
  return (
    <div>
      

      <div className="Catapiconatainer">
      <Sidebar/>
      


      <div className="tabcont" style={{width:"100%"}}>
      <Catnav/>
      <table className='Tablecontainer' style={{width:"99%"}}>
       <tbody>
        
          
         
        <tr>
            <td>
            <Link href="/Catform">
              <p className="Adminpara">ClatBatch</p>
            </Link>
            </td>
        </tr>
      
        
       </tbody>

      </table>

      </div>

      </div>
      
    
    
    </div>
  )
}

export default CatApi
